""" SAP ETD Audit Log Data Collector v1.0.0"""

import logging
import os
from datetime import datetime
import json
import httpx
import azure.functions as func
from azure.identity import ManagedIdentityCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.storage.blob import ContainerClient
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError

DCR_IMMUTABLE_ID = os.environ["DCR_IMMUTABLE_ID"]
DCR_STREAM_ALERTS = os.environ["DCR_STREAM_ALERTS"]
DCR_DCE_URL = os.environ["DCR_DCE_URL"]
ETD_UAA_URL = os.environ["ETD_UAA_URL"]
ETD_CLIENT_ID = os.environ["ETD_CLIENT_ID"]
ETD_CLIENT_SECRET = os.environ["ETD_CLIENT_SECRET"]
ETD_API_HOST = os.environ["ETD_API_HOST"] + "/alerts/v1/"
ETD_API_TIMEOUT_SECONDS = int(os.environ["ETD_API_TIMEOUT_SECONDS"])
TIMER_SCHEDULE = os.environ["TIMER_SCHEDULE"]
API_DATA = [("Alerts", DCR_STREAM_ALERTS)]
STORAGE_ACCOUNT = os.environ["AzureWebJobsStorage__accountName"]
LAST_UPDATE_CONTAINER = "lastupdated"
LAST_UPDATE_FILE = "last_update.json"

azure_http_logger = logging.getLogger(
    "azure.core.pipeline.policies.http_logging_policy"
)
azure_http_logger.setLevel(logging.WARNING)


def create_container_client(cred: ManagedIdentityCredential) -> ContainerClient:
    """Create a blob container client"""
    # create container client using managed identity
    return ContainerClient.from_container_url(
        container_url=f"https://{STORAGE_ACCOUNT}.blob.core.windows.net/{LAST_UPDATE_CONTAINER}",
        credential=cred,
    )


def get_last_updated_timestamp(cred: ManagedIdentityCredential) -> dict:
    """Get the last updated timestamp from blob storage"""

    no_updated_timestamps = {"last_update": datetime.utcnow().isoformat()}

    with create_container_client(cred) as last_update_blob_container:
        if not last_update_blob_container.exists():
            logging.info("No storage container for last update timestamp found")
            return no_updated_timestamps

        try:
            logging.info("Downloading last update timestamp file")
            last_update_blob = last_update_blob_container.download_blob(
                LAST_UPDATE_FILE
            )
            last_updated_timestamps = json.loads(last_update_blob.readall())
            return last_updated_timestamps
        except ResourceNotFoundError:
            logging.info("No last update timestamp file found in blob storage.")
            return no_updated_timestamps


def set_last_updated_timestamp(
    timestamp: datetime, cred: ManagedIdentityCredential
) -> None:
    """Set the last updated timestamp in blob storage"""

    with create_container_client(cred) as last_update_blob_container:
        if not last_update_blob_container.exists():
            logging.info("No storage container for last update timestamp found")
            last_update_blob_container.create_container()

        logging.info("Updating last update timestamp file")
        last_update_blob_container.upload_blob(
            LAST_UPDATE_FILE,
            json.dumps({"last_update": timestamp.isoformat()}),
            overwrite=True,
        )


def check_http_response(response: httpx.Response) -> httpx.Response:
    """Check the HTTP response for errors"""
    try:
        response.raise_for_status()
    except httpx.TimeoutException as exc:
        logging.error("Request timed out: %s", exc)
        raise
    except httpx.HTTPStatusError as exc:
        logging.error("HTTP error: %s, %s", exc.response.status_code, exc.response.text)
        raise
    return response


def get_data(client: httpx.Client, url: str) -> list:
    """Get data from the ETD API"""
    response = client.get(
        url=url,
    )

    return check_http_response(response)


def flatten_json(data):
    """Flatten JSON data so each row has a single triggering event"""
    flattened_data = []
    for item in data:
        base_item = {
            key: value for key, value in item.items() if key != "TriggeringEvents"
        }
        triggering_events = item.get("TriggeringEvents", [{}]) or [{}]

        for event in triggering_events:
            flattened_item = {**base_item, **event}
            flattened_data.append(flattened_item)

    return flattened_data


app = func.FunctionApp()


@app.function_name(name="ETDDataConnector")
@app.schedule(
    schedule=TIMER_SCHEDULE,
    arg_name="ETDDataConnector",
    run_on_startup=False,
    use_monitor=True,
)
# pylint: disable=invalid-name
def main(ETDDataConnector: func.TimerRequest) -> None:
    """Main function for the Azure Function App"""

    function_start_time = datetime.utcnow()

    if ETDDataConnector.past_due:
        logging.info("The timer is past due!")

    logging.info("Requesting token from ETD")
    token_response = httpx.post(
        url=f"{ETD_UAA_URL}/oauth/token?grant_type=client_credentials",
        auth=(ETD_CLIENT_ID, ETD_CLIENT_SECRET),
        headers={
            "accept": "application/x-www-form-urlencoded",
        },
    )
    etd_token = (check_http_response(token_response)).json().get("access_token")
    if not etd_token:
        raise KeyError("No access token returned from ETD")

    function_app_credential = ManagedIdentityCredential()
    logs_ingestion_client = LogsIngestionClient(
        endpoint=DCR_DCE_URL, credential=function_app_credential, logging_enable=True
    )

    last_update = get_last_updated_timestamp(cred=function_app_credential)
    last_update = datetime.fromisoformat(last_update["last_update"])

    for api_path, dcr_stream_name in API_DATA:
        with httpx.Client(
            base_url=ETD_API_HOST, timeout=ETD_API_TIMEOUT_SECONDS
        ) as client:
            client.headers = {
                "accept": "application/json",
                "Authorization": f"Bearer {etd_token}",
            }
            client.params = {
                "$expand": "TriggeringEvents",
                "$filter": f"CreationTimestamp gt {last_update.isoformat()}Z",
            }
            next_page_link = True
            request_url = api_path
            while next_page_link:

                logging.info("GET %s", request_url)
                response = get_data(url=request_url, client=client)

                data = response.json()
                etd_data = data.get("value", False)
                next_page_link = data.get("@odata.nextLink", False)

                if next_page_link:
                    request_url = next_page_link

                if etd_data:
                    etd_data = flatten_json(etd_data)
                    try:
                        logging.info(
                            "Uploading %s logs to Ingestion API", len(etd_data)
                        )
                        # pylint: disable=no-value-for-parameter
                        logs_ingestion_client.upload(
                            rule_id=DCR_IMMUTABLE_ID,
                            stream_name=dcr_stream_name,
                            logs=etd_data,
                        )
                    except HttpResponseError as exc:
                        logging.error(
                            "Error sending data to Logs Ingestion API: %s", exc
                        )
                        raise

    set_last_updated_timestamp(
        timestamp=function_start_time, cred=function_app_credential
    )
